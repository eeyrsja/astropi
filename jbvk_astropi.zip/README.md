# Team JBVK: Astro Pi Mission Space Lab Project
This is the software for our Astro Pi project.

## Life on Earth
We plan to look for a correlation between cloud cover and time of day. We are interested to learn if the amount of
cloud on the surface is affected by the local time at the surface.

**Do we get more cloud in the morning or the afternoon?**

This could be interesting as it may be useful to making weather predictions, and could tell us about the role of day/night in making clouds.

## Data
We plan to tak photos of the Earth surface using the camera. We will estimate the per-centage cloud cover of the image.
We will also record the postition of the ISS and store it with each image, and caluclate
the local time on Earth at this point.
